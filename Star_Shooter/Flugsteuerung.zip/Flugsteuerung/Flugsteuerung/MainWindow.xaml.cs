﻿using System;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using Microsoft.Kinect;
using Messages;
using System.Net;
using System.Net.Sockets;
using System.IO;

namespace Messages
{
    public class ServerMessages
    {
        public const string connected = "opSer";
        public const string disconnect = "clSer";
    }
    public class ClientMessages
    {
        public const string connected = "opCli";
        public const string disconnect = "clCli";
        public const string reset = "res";
        public const string moveStraight = "str";
        public const string moveRight = "ri";
        public const string moveSharpRight = "sri";
        public const string moveLeft = "le";
        public const string moveSharpLeft = "sle";
    }

}


namespace Flugsteuerung
{
    /// <summary>
    /// Interaktionslogik für MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        private KinectSensor myKinect;
        private WriteableBitmap colorImgBmp = null;
        private byte[] colorStreamData;
        private FlightClient client;
        private bool ignition;
        private bool connected;
        private int rightCount;
        private int rightSharpCount;
        private int leftCount;
        private int leftSharpCount;
        private int straightCount;
        private int resetCount;
        private int frameCount;
        private float deltaStraight;
        private int sharpFactor;
        private int sensibility;
        private String message;
        private String sendToServer;

        private enum Direction
        {
            Straight,
            Right,
            SharpRight,
            Left,
            SharpLeft,
            Undefined,
            Reset
        };

        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            ignition = false;
            if(KinectSensor.KinectSensors.Count == 0)
            {
                MessageBox.Show("Keine Kinect erkannt. Das Programm wird beendet.", "Bruchlandung");
                Application.Current.Shutdown();
            }
            setCounterToZero();
            sensibility = (int)sliderSensibility.Value;
            tbSliderSensibility.Text = sliderSensibility.Value.ToString();
            deltaStraight = (float)sliderDeltaTolerance.Value;
            tbSliderDeltaTolerance.Text = sliderDeltaTolerance.Value.ToString();
            sharpFactor = 4;
            message = textBoxFlight.Text;
            sendToServer = "";
        }

        private void startButton_Click(object sender, RoutedEventArgs e)
        {
            if (!ignition)
            {
                startKinect();
            }
            else
            {
                MessageBox.Show("Die Kinect läuft bereits.", "Status Kinect");
            }
        }

        private void startKinect()
        {
            try
            {
                if (myKinect == null)
                {
                    myKinect = KinectSensor.KinectSensors[0];
                }
                myKinect.ColorStream.Enable();
                myKinect.SkeletonStream.Enable();
                myKinect.Start();
            }
            catch
            {
                MessageBox.Show("Die Kinect konnte nicht initialisiert werden. Das Programm wird beendet.", "Bruchlandung");
                Application.Current.Shutdown();
            }
            myKinect.ColorFrameReady += MyKinect_ColorFrameReady;
            myKinect.SkeletonFrameReady += MyKinect_SkeletonFrameReady;
            ignition = true;
        }

        private void stopKinect()
        {
            myKinect.ColorStream.Disable();
            myKinect.SkeletonStream.Disable();
            myKinect.Stop();
            kinectCanvas.Source = null;
            ignition = false;
        }
        
        // Wird bei dem Event "neue Skelettdaten vorhanden" aufgerufen
        private void MyKinect_SkeletonFrameReady(object sender, SkeletonFrameReadyEventArgs e)
        {
            Skeleton[] skeletons = null;
            Direction direction = Direction.Undefined;
            using(SkeletonFrame skelFrame = e.OpenSkeletonFrame())
            {
                if (skelFrame != null)
                {
                    skeletons = new Skeleton[skelFrame.SkeletonArrayLength];
                    skelFrame.CopySkeletonDataTo(skeletons);
                }
            }
            if(skeletons == null)
            {
                return;
            }
            foreach (Skeleton skeleton in skeletons)
            {
                if (skeleton.TrackingState == SkeletonTrackingState.Tracked)
                {
                    // Rechte Seite: Schulter, Ellbogen, Hand und Hüfte (für die Reset Möglichkeit)
                    Joint rightShoulderJoint = skeleton.Joints[JointType.ShoulderRight];
                    Joint rightElbowJoint = skeleton.Joints[JointType.ElbowRight];
                    Joint rightHandJoint = skeleton.Joints[JointType.HandRight];
                    Joint rightHip = skeleton.Joints[JointType.HipRight];

                    // Linke Seite: Schulter, Ellbogen, Hand und Hüfte (für die Reset Möglichkeit)
                    Joint leftShoulderJoint = skeleton.Joints[JointType.ShoulderLeft];
                    Joint leftElbowJoint = skeleton.Joints[JointType.ElbowLeft];
                    Joint leftHandJoint = skeleton.Joints[JointType.HandLeft];
                    Joint leftHip = skeleton.Joints[JointType.HipLeft];


                    direction = flightControll(rightShoulderJoint.Position.Y,
                                               rightElbowJoint.Position.Y,
                                               rightHandJoint.Position.X,
                                               rightHandJoint.Position.Y,
                                               leftShoulderJoint.Position.Y,
                                               leftElbowJoint.Position.Y,
                                               leftHandJoint.Position.X,
                                               leftHandJoint.Position.Y,
                                               rightHip.Position.X,
                                               leftHip.Position.X);

                    //Einfache Version der Methode flightControll. Verwendet lediglich die Positionen der beiden Händen.
                    //scharf Rechts, scharf Links und Reset werden von dieser Funktion nicht erkannt
                    //direction = flightControll(rightHandJoint.Position.Y, leftHandJoint.Position.Y);

                    switch (direction)
                    {
                        case Direction.Straight:
                            straightCount++;
                            frameCount++;
                            rightCount = 0;
                            rightSharpCount = 0;
                            leftCount = 0;
                            leftSharpCount = 0;
                            resetCount = 0;
                            break;
                        case Direction.Right:
                            rightCount++;
                            frameCount++;
                            straightCount = 0;
                            rightSharpCount = 0;
                            leftCount = 0;
                            leftSharpCount = 0;
                            resetCount = 0;
                            break;
                        case Direction.SharpRight:
                            rightSharpCount++;
                            frameCount++;
                            straightCount = 0;
                            rightCount = 0;
                            leftCount = 0;
                            leftSharpCount = 0;
                            resetCount = 0;
                            break;
                        case Direction.Left:
                            leftCount++;
                            frameCount++;
                            straightCount = 0;
                            rightCount = 0;
                            rightSharpCount = 0;
                            leftSharpCount = 0;
                            resetCount = 0;
                            break;
                        case Direction.SharpLeft:
                            leftSharpCount++;
                            frameCount++;
                            straightCount = 0;
                            rightCount = 0;
                            rightSharpCount = 0;
                            leftCount = 0;
                            resetCount = 0;
                            break;
                        case Direction.Reset:
                            resetCount++;
                            frameCount++;
                            straightCount = 0;
                            rightCount = 0;
                            rightSharpCount = 0;
                            leftCount = 0;
                            leftSharpCount = 0;
                            break;
                        case Direction.Undefined:
                            setCounterToZero();
                            break;
                        default:
                            setCounterToZero();
                            break;
                    }
                    if (frameCount == sensibility)
                    {
                        if (straightCount == sensibility)
                        {
                            message = "Gerade";
                            sendToServer = ClientMessages.moveStraight;
                        }
                        else if (rightCount == sensibility)
                        {
                            message = "Rechts";
                            sendToServer = ClientMessages.moveRight;
                        }
                        else if (rightSharpCount == sensibility)
                        {
                            message = "scharf Rechts";
                            sendToServer = ClientMessages.moveSharpRight;
                        }
                        else if (leftCount == sensibility)
                        {
                            message = "Links";
                            sendToServer = ClientMessages.moveLeft;
                        }
                        else if (leftSharpCount == sensibility)
                        {
                            message = "scharf Links";
                            sendToServer = ClientMessages.moveSharpLeft;
                        }
                        else if (resetCount == sensibility)
                        {
                            message = "Reset";
                            sendToServer = ClientMessages.reset;
                        }
                        setCounterToZero();
                    }
                }
            }
            textBoxFlight.Text = message;
            if (connected && sendToServer != "")
            {
                client.sendControllData(sendToServer);
            }
            sendToServer = "";
        }
        
        private void stopButton_Click(object sender, RoutedEventArgs e)
        {
            if (ignition)
            {
                stopKinect();
            }
            else
            {
                MessageBox.Show("Die Kinect wurde noch nicht gestartet." , "Status der Kinect");
            }
        }

        // Wird bei dem Event "neue Video Daten vorhanden" aufgerufen
        private void MyKinect_ColorFrameReady(object sender, ColorImageFrameReadyEventArgs e)
        {
            using (ColorImageFrame colorFrame = e.OpenColorImageFrame())
            {
                if(colorFrame == null)
                {
                    return;
                }
                if(colorStreamData == null)
                {
                    colorStreamData = new byte[colorFrame.PixelDataLength];
                }
                colorFrame.CopyPixelDataTo(colorStreamData);

                if(colorImgBmp == null)
                {
                    this.colorImgBmp = new WriteableBitmap(colorFrame.Width, colorFrame.Height, 96, 96, PixelFormats.Bgr32, null);
                }
                this.colorImgBmp.WritePixels(new Int32Rect(0, 0, colorFrame.Width, colorFrame.Height), 
                     colorStreamData, colorFrame.Width * colorFrame.BytesPerPixel, 0);

                kinectCanvas.Source = colorImgBmp;
            }
        }

        //In dieser Methode findet die Gestenerkennung statt. Er benötigt dazu folgende Werte:
        //- rS = rechte Schulter (Y Wert)
        //- lS = linke Shulter (Y Wert)
        //- rE = rechter Ellbogen (Y Wert)
        //- lE = linker Ellbogen (Y Wert)
        //- rH = rechte Hand (Y Wert)
        //- lH = linke Hand (Y Wert)
        //- rHX = rechte Hand (X Wert)
        //- lHX = linke Hand(X Wert)
        //- rHip = rechte Hüfte (X Wert)
        //- lHip = linke Hüfte  (X Wert)
        private Direction flightControll(float rS, float rE, float rHX, float rH, float lS, float lE, float lHX, float lH, float rHip, float lHip)
        {
            if(Math.Abs(rH - lH) <= deltaStraight && Math.Abs(lE-lH) <= deltaStraight/2 && Math.Abs(rE-rH) <= deltaStraight/2)
            {
                return Direction.Straight;
            }
            if (lS > rS && lE > rE && lH > rH && (lH - rH) >= (deltaStraight * sharpFactor))
            {
                return Direction.SharpRight;
            }
            if (lS > rS && lE > rE && lH > rH)
            {
                return Direction.Right;
            }
            if (rS > lS && rE > lE && rH > lH && (rH - lH) >= (deltaStraight * sharpFactor))
            {
                return Direction.SharpLeft;
            }
            if (rS > lS && rE > lE && rH > lH)
            {
                return Direction.Left;
            }
            if(Math.Abs(rHip-rHX) <= 3*deltaStraight && Math.Abs(lHip-lHX) <= 3*deltaStraight)
            {
                return Direction.Reset;
            }
            return Direction.Undefined;

        }

        // Sehr einfache experimentelle Funktion zur bestimmung der Gesten. Es funktionieren hier nur rechts, links und gerade.
        private Direction flightControll(float rH, float lH)
        {
            if(Math.Abs(rH - lH) <= deltaStraight)
            {
                return Direction.Straight;
            }
            if(lH > rH)
            {
                return Direction.Right;
            }
            if(rH > lH)
            {
                return Direction.Left;
            }

            return Direction.Undefined;
        }

        private void sliderSensibility_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if (tbSliderSensibility != null)
            {
                tbSliderSensibility.Text = "" + (int)sliderSensibility.Value;
            }
            sensibility = (int)sliderSensibility.Value;
        }

        private void setCounterToZero()
        {
            straightCount = 0;
            rightCount = 0;
            rightSharpCount = 0;
            leftCount = 0;
            leftSharpCount = 0;
            resetCount = 0;
            frameCount = 0;
        }

        private void sliderDeltaTolerance_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {

            if (tbSliderDeltaTolerance != null)
            {
                tbSliderDeltaTolerance.Text = "" + (float)sliderDeltaTolerance.Value;
            }
            deltaStraight = (float)sliderDeltaTolerance.Value;
        }

        private void connectButton_Click(object sender, RoutedEventArgs e)
        {
            if (!connected)
            {
                if (!ignition)
                {
                    startKinect();
                }
                    if (ipIsCorrect(textBoxIP.Text) && textBoxPort.Text != null)
                    {
                        client = FlightClient.getInstance;
                        if (client.connect(textBoxIP.Text, textBoxPort.Text))
                        {
                            connected = true;
                        }
                        else
                        {
                        MessageBox.Show("Es konnte keine Verbindung zum Server aufgebaut werden.", "TCP Kommunikation");                        }
                    }
                    else
                    {
                        MessageBox.Show("Sie haben keine korrekte IP Adresse eingegeben.", "TCP Kommunikation");
                    }
            }
            else
            {
                MessageBox.Show("Sie sind bereits verbunden.", "TCP Kommunikation");
            }
                
        }

        private void closeButton_Click(object sender, RoutedEventArgs e)
        {
            if(connected && client != null)
            {
                client.disconnect();
                client = null;
            }
            if (ignition)
            {
                stopKinect();
            }
            Application.Current.Shutdown();
        }

        private bool ipIsCorrect (string ip)
        {
            Regex regular = new Regex("^([0-9]{1,2}|[1-2][0-9]{2})\\.([0-9]{1,2}|[1-2][0-9]{2})\\.([0-9]{1,2}|[1-2][0-9]{2})\\.([0-9]{1,2}|[1-2][0-9]{2})$");

            if (regular.IsMatch(ip))
            {
                string[] numbers = ip.Split('.');
                int num;

                foreach (string number in numbers)
                {
                    num = int.Parse(number);
                    if(num >= 0 && num <= 255){
                        continue;
                    }
                    return false;
                }
                return true;
            }
            return false;
        }
    }

    public class FlightClient
    {

        private static FlightClient clientInstance;
        private NetworkStream stream;
        private BinaryWriter sender;
        private BinaryReader receiver;
        private TcpClient client;
        private bool connected;
        private String message;

        private FlightClient()
        {
            client = new TcpClient();
            connected = false;
        }

        public static FlightClient getInstance
        {
            get
            {
                if (clientInstance == null)
                {
                    clientInstance = new FlightClient();
                }
                return clientInstance;
            }
        }

        public bool connect(String ip, String port)
        {
            try
            {
                client.Connect(IPAddress.Parse(ip), int.Parse(port));
                stream = client.GetStream();
                sender = new BinaryWriter(stream);
                receiver = new BinaryReader(stream);
                sender.Write(ClientMessages.connected);
                message = receiver.ReadString();
                if (message == ServerMessages.connected)
                {
                    connected = true;
                }
                return connected;   
            }
            catch
            {
                return connected;
            }
        }

        public void sendControllData(String data)
        {
            if (connected)
            {
                try
                { 
                    sender.Write(data);
                }
                catch
                {
                    return;
                }
            }
        }

        public void disconnect()
        {
            sendControllData(ClientMessages.disconnect);
            sender.Close();
            receiver.Close();
            stream.Close();
            client.Close();
            connected = false;
        }
    }
}
