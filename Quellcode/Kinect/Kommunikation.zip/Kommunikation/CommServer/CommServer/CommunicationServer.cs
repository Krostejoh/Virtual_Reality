﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Sockets;
using System.IO;
using SharedComponent;

namespace SharedComponent
{
    public class ServerMessages
    {
        public const string AcknowledgeOK = "OK";
        public const string AcknowledgeCancel = "Cancel";
        public const string Disconnect = "Bye";
    }

    public class ClientMessages
    {
        public const string RequestConnect = "Hello";
        public const string Disconnect = "Bye";
    }



}


namespace CommServer
{
    class CommunicationServer
    {
        static void Main(string[] args)
        {

            TcpListener listener = new TcpListener(IPAddress.Parse("127.0.0.1"), 8000);
            Console.WriteLine("Initialisiere Anschluss.");
            listener.Start();
            Console.WriteLine("Warte auf eingehende Verbindungsanforderungen...");

            try
            {
                TcpClient client = listener.AcceptTcpClient();
                Console.WriteLine("Verbindung akzeptiert.");

                NetworkStream stream = client.GetStream();

                BinaryWriter write = new BinaryWriter(stream);

                BinaryReader read = new BinaryReader(stream);

                if(read.ReadString() == ClientMessages.RequestConnect)
                {
                    write.Write(ServerMessages.AcknowledgeOK);
                    Console.WriteLine("Verbindung beendet.");

                    while(read.ReadString() != ClientMessages.Disconnect)
                    {

                    }

                    Console.WriteLine();
                    Console.WriteLine("Verbindungstrennungsanforderung empfangen.");
                    write.Write(ServerMessages.Disconnect);


                }
                else
                {
                    Console.WriteLine("Verbindung konnte nicht beendet werden.");
                }

                client.Close();
                Console.WriteLine("Verbindung getrennt.");
                listener.Stop();
                Console.WriteLine("Listener gestoppt.");

            }
            catch (Exception excep)
            {
                Console.WriteLine(excep.ToString());
            }

            Console.ReadLine();
        }
    }
}
