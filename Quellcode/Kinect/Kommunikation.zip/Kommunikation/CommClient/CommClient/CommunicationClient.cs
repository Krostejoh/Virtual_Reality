﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Sockets;
using System.IO;
using System.Threading;
using Messages;

namespace Messages
{
    public class ServerMessages
    {
        public const string connected = "openSer";
        public const string disconnect = "closeSer";
    }
    public class ClientMessages
    {
        public const string connected = "openCli";
        public const string disconnect = "closeCli";
        public const string reset = "reset";
        public const string moveStraight = "straight";
        public const string moveRight = "right";
        public const string moveSharpRight = "sharpright";
        public const string moveLeft = "left";
        public const string moveSharpLeft = "sharpleft";
    }

}



namespace CommClient
{
    class CommunicationClient
    {
        private Thread thread;
        private static String message;
        private static NetworkStream stream;
        private static BinaryWriter writer;
        private static BinaryReader reader;
       


        static void Main(string[] args)
        {
            TcpClient client = new TcpClient();

            try
            {
                Console.WriteLine("Verbindungsversuch mit Server über Anschluss 8000.");
                client.Connect(IPAddress.Parse("127.0.0.1"), 8000);
                stream = client.GetStream();
                writer = new BinaryWriter(stream);
                reader = new BinaryReader(stream);

                writer.Write(ClientMessages.connected);

                while (reader.ReadString() != ServerMessages.connected) { }

                sendControllData();





                if (reader.ReadString() == "Connected")
                {
                    writer.Write("Verbindung hergestellt. Sende Steuerdaten.");
                    for (int i = 0; i < 10; i++)
                    {
                        Thread.Sleep(200);
                        switch (i)
                        {
                            case 0:
                                writer.Write("Left");
                                break;
                            case 1:
                                writer.Write("Straight");
                                break;
                            case 2:
                                writer.Write("Left");
                                break;
                            case 3:
                                writer.Write("Right");
                                break;
                            case 4:
                                writer.Write("Straight");
                                break;
                            case 5:
                                writer.Write("Right");
                                break;
                            case 6:
                                writer.Write("Right");
                                break;
                            case 7:
                                writer.Write("Left");
                                break;
                            case 8:
                                writer.Write("Straight");
                                break;
                            case 9:
                                writer.Write("Straight");
                                break;
                            default:
                                writer.Write("Disconnect");
                                break;
                        }
                    }
                }


                if (reader.ReadString() == ServerMessages.AcknowledgeOK)
                {
                    Console.WriteLine("Verbunden.");
                    Console.WriteLine("Enter drücken, um Verbindung zu trennen.");
                    Console.ReadLine();
                    Console.WriteLine("Trenne Verbindung...");
                    writer.Write(ClientMessages.Disconnect);
                }
                else
                {
                    Console.WriteLine("Verbindung nicht beendet.");
                }

                //client.Close();
                Console.WriteLine("Anschluss geschlossen.");
            }
            catch (Exception excep)
            {
                Console.WriteLine(excep.ToString());
            }

            Console.ReadLine();
            client.Close();

        }

        public static void sendControllData()
        {
            message = "";
            while(message != ClientMessages.disconnect)
            {
                //Hier müssen die Controlldaten rein
            }  
        }
    }
}

