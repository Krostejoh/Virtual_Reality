﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Microsoft.Kinect;

namespace FirstSkeletonTracking
{
    /// <summary>
    /// Interaktionslogik für MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        KinectSensor myKinect;

        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            if (KinectSensor.KinectSensors.Count == 0)
            {
                MessageBox.Show("No Kinects detected", "Head Position Viewer");
                Application.Current.Shutdown();
                return;
            }

            myKinect = KinectSensor.KinectSensors[0];

            try
            {
                myKinect.SkeletonStream.Enable();
                myKinect.Start();
            }
            catch
            {
                MessageBox.Show("Kinect initialise failed", "Head Position Viewer");
                Application.Current.Shutdown();
            }

            myKinect.SkeletonFrameReady += MyKinect_SkeletonFrameReady;

        }

        private void MyKinect_SkeletonFrameReady(object sender, SkeletonFrameReadyEventArgs e)
        {
            string message = "No Skeleton Data";
            string message2 = "No Skeleton Data";

            Skeleton[] skeletons = null;

            using (SkeletonFrame frame = e.OpenSkeletonFrame())
            {
                if(frame != null)
                {
                    skeletons = new Skeleton[frame.SkeletonArrayLength];
                    frame.CopySkeletonDataTo(skeletons);
                }
            }
            
            if (skeletons == null)
            {
                return;
            }

            foreach (Skeleton skeleton in skeletons)
            {

                if (skeleton.TrackingState == SkeletonTrackingState.Tracked)
                {
                    Joint rightHandJoint = skeleton.Joints[JointType.HandRight];
                    SkeletonPoint rightHandPosition = rightHandJoint.Position;
                    Joint leftHandJoint = skeleton.Joints[JointType.HandLeft];
                    SkeletonPoint leftHandPosition = leftHandJoint.Position;

                    message = string.Format("Right Hand: X:{0:0.0} Y:{1:0.0} Z:{2:0.0}", rightHandPosition.X, rightHandPosition.Y, rightHandPosition.Z);
                    message2 = string.Format("Left Hand: X:{0:0.0} Y:{1:0.0} Z:{2:0.0}", leftHandPosition.X, leftHandPosition.Y, leftHandPosition.Z);
                }
            }

            StatusTextRA.Text = message;
            StatusTextLA.Text = message2;
            
        }
    }
}
