﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Microsoft.Kinect;

namespace KinectCam
{
    /// <summary>
    /// Interaktionslogik für MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        KinectSensor myKinect;
        int redOffset = 0;
        int greenOffset = 0;
        int blueOffset= 0;

        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {

            if(KinectSensor.KinectSensors.Count == 0)
            {
                MessageBox.Show("Keine Kinect erkannt", "Camera Viewer");
                Application.Current.Shutdown();
            }
            try
            {
                myKinect = KinectSensor.KinectSensors[0];
                myKinect.ColorStream.Enable();
                //myKinect.DepthStream.Enable();
                myKinect.Start();
            }
            catch
            {
                MessageBox.Show("Initialisierung der Kinect fehlgeschlagen", "Camera Viewer");
                Application.Current.Shutdown();
            }

            //myKinect.DepthFrameReady += MyKinect_DepthFrameReady;
            myKinect.ColorFrameReady += MyKinect_ColorFrameReady;
        }

        WriteableBitmap colorImageBitmap = null;
        byte[] colorData = null;

        private void MyKinect_DepthFrameReady(object sender, DepthImageFrameReadyEventArgs e)
        {
            using (DepthImageFrame depthFrame = e.OpenDepthImageFrame())
            {
                if(depthFrame == null)
                {
                    return;
                }

                short[] depthData = new short[depthFrame.PixelDataLength];
                depthFrame.CopyPixelDataTo(depthData);

                kinectVideo.Source = BitmapSource.Create(
                    depthFrame.Width,
                    depthFrame.Height,
                    96,
                    96,
                    PixelFormats.Gray16,
                    null,
                    depthData,
                    depthFrame.Width * depthFrame.BytesPerPixel);

            }
        }

        private void MyKinect_ColorFrameReady(object sender, ColorImageFrameReadyEventArgs e)
        {
            using (ColorImageFrame colorFrame = e.OpenColorImageFrame())
            {
                if(colorFrame == null)
                {
                    return;
                }
                if(colorData == null)
                {
                    colorData = new byte[colorFrame.PixelDataLength];
                }

                colorFrame.CopyPixelDataTo(colorData);

                int newValue;

                    for (int i = 0; i < colorData.Length; i = i + 4)
                    {
                        newValue = colorData[i] + blueOffset;
                        if (newValue < 0)
                        {
                            newValue = 0;
                        }
                        if (newValue > 255)
                        {
                            newValue = 255;
                        }
                        colorData[i] = (byte)newValue;

                        newValue = colorData[i+1] + greenOffset;
                        if (newValue < 0)
                        {
                            newValue = 0;
                        }
                        if (newValue > 255)
                        {
                            newValue = 255;
                        }
                        colorData[i+1] = (byte)newValue;

                        newValue = colorData[i + 2] + redOffset;
                        if (newValue < 0)
                        {
                            newValue = 0;
                        }
                        if (newValue > 255)
                        {
                            newValue = 255;
                        }
                        colorData[i + 2] = (byte)newValue;

                    //colorData[i] += 50;
                    //if(colorData[i] > 255)
                    //{
                    //    colorData[i] = (byte) 255;
                    //}
                    //int oldColor = colorData[i];
                    //newColor = (int)colorData[i] + 50;
                    //if (newColor > 255)
                    //{
                    //    newColor = 255;
                    //}
                    //colorData[i] = (byte)newColor;

                }

                //mit dem nachfolgenden Code wird pro Frame ein neues Bitmap erzeugt, dass die Pixeldaten der Kinect enthält.
                //das kostet eine Menge Resourcen und ist daher in dieser Form nicht zu empfehlen. Zum Testen kann die Auskommentierung
                //aufgehoben werden.
                //kinectVideo.Source = BitmapSource.Create(
                //    colorFrame.Width, 
                //    colorFrame.Height, 
                //    96, 
                //    96, 
                //    PixelFormats.Bgr32, 
                //    null, 
                //    colorData, 
                //    colorFrame.Width * colorFrame.BytesPerPixel);


                // Die Zeilen bis "kinectVideo.Source = colorImageBitmap;" stellen die bessere Methode dar um den VideoStream der Kinect 
                // sichtbar zu machen. Sollte die obige Methode ausprobiert werden müssen alle Zeilen bis einschließlich 
                // "kinectVideo.Source = colorImageBitmap;" auskommentiert werden.
                if (colorImageBitmap == null)
                {
                    this.colorImageBitmap = new WriteableBitmap(
                        colorFrame.Width,
                        colorFrame.Height,
                        96, 96,
                        PixelFormats.Bgr32, null);
                }

                this.colorImageBitmap.WritePixels(
                    new Int32Rect(0, 0, colorFrame.Width, colorFrame.Height),
                    colorData,
                    colorFrame.Width * colorFrame.BytesPerPixel, 0);

                kinectVideo.Source = colorImageBitmap;

            }
        }

        private void blueSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            blueOffset = (int)blueSlider.Value;
        }

        private void greenSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            greenOffset = (int)greenSlider.Value;
        }

        private void redSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            redOffset = (int)redSlider.Value;
        }
    }
}
